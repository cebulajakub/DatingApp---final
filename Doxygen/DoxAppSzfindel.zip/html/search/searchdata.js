var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvw",
  1: "acdehimsuw",
  2: "s",
  3: "_adehimpuw",
  4: "acdefghilmoprstu",
  5: "_ab",
  6: "i",
  7: "_abcdfhilmnprstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "properties"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne",
  6: "Definicje typów",
  7: "Właściwości"
};

