var searchData=
[
  ['weather_0',['weather',['../class_szfindel_1_1_models_1_1_weather_api.html#a39e9375802b49db6909808cf82c99a8a',1,'Szfindel::Models::WeatherApi']]],
  ['wind_1',['wind',['../class_szfindel_1_1_models_1_1_weather_api.html#a161ac7e827035ebb3bed44b52eae0610',1,'Szfindel::Models::WeatherApi']]]
];
