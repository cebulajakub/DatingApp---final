var searchData=
[
  ['privacy_0',['Privacy',['../class_szfindel_1_1_controllers_1_1_home_controller.html#a8c056972570055385a484b2f73b7a9d4',1,'Szfindel::Controllers::HomeController']]]
];
