var searchData=
[
  ['updateaccount_0',['UpdateAccount',['../interface_szfindel_1_1_interface_1_1_i_account.html#ad27622200eef115d36b2443c1c699873',1,'Szfindel.Interface.IAccount.UpdateAccount()'],['../class_szfindel_1_1_controllers_1_1_account_controller.html#a48c4fe6598fe442abc80fe13c3a17628',1,'Szfindel.Controllers.AccountController.UpdateAccount()'],['../class_szfindel_1_1_controllers_1_1_account_controller.html#a2c1b76ec0f9c6995145b84c60f1b2819',1,'Szfindel.Controllers.AccountController.UpdateAccount([FromForm] AccountUser updatedAccount, IFormFile? file)'],['../class_szfindel_1_1_repo_1_1_account_repo.html#a5995027b9a64a10beb55708752ce0a8a',1,'Szfindel.Repo.AccountRepo.UpdateAccount()']]],
  ['updateimage_1',['UpdateImage',['../interface_szfindel_1_1_interface_1_1_i_account.html#a902cacc1aee979cf3a36c8b90e571f87',1,'Szfindel.Interface.IAccount.UpdateImage()'],['../class_szfindel_1_1_repo_1_1_account_repo.html#a1f977ce3ec1004aff7c68bce9d716769',1,'Szfindel.Repo.AccountRepo.UpdateImage()']]],
  ['updatematch_2',['UpdateMatch',['../interface_szfindel_1_1_interface_1_1_i_match.html#a9856172483da9b865176dde4a91f8100',1,'Szfindel.Interface.IMatch.UpdateMatch()'],['../class_szfindel_1_1_repo_1_1_match_repo.html#ad60121f03de224b7395aafaac145b3a5',1,'Szfindel.Repo.MatchRepo.UpdateMatch()']]],
  ['useauthorization_3',['UseAuthorization',['../_program_8cs.html#aee15d952b351633e37db07ef3357d634',1,'Program.cs']]],
  ['usehttpsredirection_4',['UseHttpsRedirection',['../_program_8cs.html#aa4d447fc3129a3aa301d736b8bd04ae9',1,'Program.cs']]],
  ['usercontroller_5',['UserController',['../class_szfindel_1_1_controllers_1_1_user_controller.html#a985a6287d14d777d37f6a24cc518edb0',1,'Szfindel::Controllers::UserController']]],
  ['userouting_6',['UseRouting',['../_program_8cs.html#a94c810d266751293a2d511a720a5625f',1,'Program.cs']]],
  ['userrepo_7',['UserRepo',['../class_szfindel_1_1_repo_1_1_user_repo.html#a822d075551b3b4e997675fd28139ce48',1,'Szfindel::Repo::UserRepo']]],
  ['usesession_8',['UseSession',['../_program_8cs.html#a5c33896bff93d8072abd01914b8370f8',1,'Program.cs']]],
  ['usestaticfiles_9',['UseStaticFiles',['../_program_8cs.html#a906a3ce545279a7a73941f1d7b64d7cf',1,'Program.cs']]],
  ['ustawienia_10',['Ustawienia',['../class_szfindel_1_1_controllers_1_1_account_controller.html#ae88b715c072a974a77d5562a67793166',1,'Szfindel::Controllers::AccountController']]]
];
