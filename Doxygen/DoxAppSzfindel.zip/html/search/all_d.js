var searchData=
[
  ['onmodelcreating_0',['OnModelCreating',['../class_szfindel_1_1_models_1_1_database_context.html#adf60bd081b738cb5028fb23472933d28',1,'Szfindel::Models::DatabaseContext']]],
  ['ourmatch_1',['OurMatch',['../interface_szfindel_1_1_interface_1_1_i_match.html#ae0918b7f2b8882f3de36ad8ce0644932',1,'Szfindel.Interface.IMatch.OurMatch()'],['../class_szfindel_1_1_repo_1_1_match_repo.html#a04b8c392d840b58bac3f7fc31d70a66b',1,'Szfindel.Repo.MatchRepo.OurMatch()']]]
];
