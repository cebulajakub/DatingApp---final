var searchData=
[
  ['feels_5flike_0',['feels_like',['../class_szfindel_1_1_models_1_1_main.html#afee2359e1004d7b7a978ceb1ae993479',1,'Szfindel::Models::Main']]],
  ['filteredusers_1',['FilteredUsers',['../class_szfindel_1_1_controllers_1_1_account_controller.html#a29ee867340c8a11c4baff617a39e69a3',1,'Szfindel::Controllers::AccountController']]]
];
