var searchData=
[
  ['errorviewmodel_0',['ErrorViewModel',['../class_szfindel_1_1_models_1_1_error_view_model.html',1,'Szfindel::Models']]]
];
