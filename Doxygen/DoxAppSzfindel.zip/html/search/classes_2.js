var searchData=
[
  ['databasecontext_0',['DatabaseContext',['../class_szfindel_1_1_models_1_1_database_context.html',1,'Szfindel::Models']]]
];
