var searchData=
[
  ['databasecontext_0',['DatabaseContext',['../class_szfindel_1_1_models_1_1_database_context.html',1,'Szfindel.Models.DatabaseContext'],['../class_szfindel_1_1_models_1_1_database_context.html#a1e8cf544b0328b1c2f6375e964a20e5b',1,'Szfindel.Models.DatabaseContext.DatabaseContext()']]],
  ['databasecontext_2ecs_1',['DatabaseContext.cs',['../_database_context_8cs.html',1,'']]],
  ['datetime_2',['DateTime',['../class_szfindel_1_1_models_1_1_message.html#a1fbed2dcca58f09deae062f53efe5944',1,'Szfindel::Models::Message']]],
  ['deg_3',['deg',['../class_szfindel_1_1_models_1_1_wind.html#ac97e625c328673609e06922b2acb9f13',1,'Szfindel::Models::Wind']]],
  ['delete_4',['Delete',['../interface_szfindel_1_1_interface_1_1_i_match.html#ab86f8abd381599185681dd7020a12cc0',1,'Szfindel.Interface.IMatch.Delete()'],['../class_szfindel_1_1_repo_1_1_match_repo.html#a5894b11e386769c9e0306bdf9e25c1c4',1,'Szfindel.Repo.MatchRepo.Delete()']]],
  ['deleteaccount_5',['DeleteAccount',['../class_szfindel_1_1_controllers_1_1_account_controller.html#ab67aa307b76f810494bf7bac25751658',1,'Szfindel::Controllers::AccountController']]],
  ['deleteaccountbyid_6',['DeleteAccountByID',['../interface_szfindel_1_1_interface_1_1_i_account.html#a2ca205f14c1673c5f823941e86313403',1,'Szfindel.Interface.IAccount.DeleteAccountByID()'],['../class_szfindel_1_1_repo_1_1_account_repo.html#ab85c73a21a1b977918e193bcc0554c75',1,'Szfindel.Repo.AccountRepo.DeleteAccountByID()']]],
  ['deletematch_7',['DeleteMatch',['../class_szfindel_1_1_controllers_1_1_match_controller.html#a0a906a7648bcc3e45cd292d25dfd09e6',1,'Szfindel::Controllers::MatchController']]],
  ['deletemessagesusers_8',['DeleteMessagesUsers',['../interface_szfindel_1_1_interface_1_1_i_message.html#a2226b86a2879ae1e946c47a3824246bf',1,'Szfindel.Interface.IMessage.DeleteMessagesUsers()'],['../class_szfindel_1_1_repo_1_1_message_repo.html#abfc57989cba31645a3f18a391b3c950d',1,'Szfindel.Repo.MessageRepo.DeleteMessagesUsers()']]],
  ['deleteuserbyid_9',['DeleteUserById',['../interface_szfindel_1_1_interface_1_1_i_user.html#a5805fd5cb2397e934912a757ffc2d8a5',1,'Szfindel.Interface.IUser.DeleteUserById()'],['../class_szfindel_1_1_repo_1_1_user_repo.html#a1d22662ab325a43eadaa7d624508b723',1,'Szfindel.Repo.UserRepo.DeleteUserById()']]],
  ['deleteusershobbiesbyid_10',['DeleteUsersHobbiesByID',['../interface_szfindel_1_1_interface_1_1_i_hobby.html#af8f2e0ee994822e92706ab1ecdda9882',1,'Szfindel.Interface.IHobby.DeleteUsersHobbiesByID()'],['../class_szfindel_1_1_repo_1_1_hobby_repo.html#a408e1978225f769a1106b1d944583d22',1,'Szfindel.Repo.HobbyRepo.DeleteUsersHobbiesByID()']]],
  ['deleteusersmatchesbyid_11',['DeleteUsersMatchesByID',['../interface_szfindel_1_1_interface_1_1_i_match.html#ae95d74d36893701a306da20c32f526e0',1,'Szfindel.Interface.IMatch.DeleteUsersMatchesByID()'],['../class_szfindel_1_1_repo_1_1_match_repo.html#a1cfcf4861e6c1179944c5924d8f378a0',1,'Szfindel.Repo.MatchRepo.DeleteUsersMatchesByID()']]],
  ['description_12',['description',['../class_szfindel_1_1_models_1_1_weather.html#adb0043ae583fdb75c75c3d638d348877',1,'Szfindel::Models::Weather']]],
  ['dt_13',['dt',['../class_szfindel_1_1_models_1_1_weather_api.html#a06f547423991fcad7cfe5326f4059f54',1,'Szfindel::Models::WeatherApi']]]
];
