var searchData=
[
  ['base_0',['base',['../class_szfindel_1_1_models_1_1_weather_api.html#ad2705cd02c5cbc5ef6dfd6f071888387',1,'Szfindel::Models::WeatherApi']]]
];
