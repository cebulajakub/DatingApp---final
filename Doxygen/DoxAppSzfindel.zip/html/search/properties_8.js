var searchData=
[
  ['lat_0',['lat',['../class_szfindel_1_1_models_1_1_coord.html#addfc5c60a5812f5110784b1ff3283666',1,'Szfindel::Models::Coord']]],
  ['lon_1',['lon',['../class_szfindel_1_1_models_1_1_coord.html#a5068ef771d42eb6c32553b8a8b0f7195',1,'Szfindel::Models::Coord']]]
];
