var searchData=
[
  ['name_0',['name',['../class_szfindel_1_1_models_1_1_weather_api.html#a5ab02ff7c9952a85187b28c4d022222c',1,'Szfindel::Models::WeatherApi']]],
  ['name_1',['Name',['../class_szfindel_1_1_models_1_1_account_user.html#ab7dbbad362b90f40e70c06687b2a2c23',1,'Szfindel::Models::AccountUser']]]
];
