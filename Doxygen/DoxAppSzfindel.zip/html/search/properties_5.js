var searchData=
[
  ['feels_5flike_0',['feels_like',['../class_szfindel_1_1_models_1_1_main.html#afee2359e1004d7b7a978ceb1ae993479',1,'Szfindel::Models::Main']]]
];
