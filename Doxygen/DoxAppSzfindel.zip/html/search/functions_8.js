var searchData=
[
  ['like_0',['Like',['../class_szfindel_1_1_controllers_1_1_match_controller.html#a6d191efd1a56dba111d2548b46befddb',1,'Szfindel::Controllers::MatchController']]],
  ['login_1',['Login',['../class_szfindel_1_1_controllers_1_1_user_controller.html#a623f63cbdeea3a17ef7d7b618608fe04',1,'Szfindel.Controllers.UserController.Login()'],['../class_szfindel_1_1_controllers_1_1_user_controller.html#a2fecfe0085c4ebdf9e4624646ef01e9d',1,'Szfindel.Controllers.UserController.Login([FromForm] User user)']]],
  ['logout_2',['Logout',['../class_szfindel_1_1_controllers_1_1_user_controller.html#a57ca172b46432069f8b87c09ffeea194',1,'Szfindel::Controllers::UserController']]]
];
