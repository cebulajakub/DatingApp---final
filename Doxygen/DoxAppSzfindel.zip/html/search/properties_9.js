var searchData=
[
  ['main_0',['main',['../class_szfindel_1_1_models_1_1_weather_api.html#a48c0596dcc9e79fd2f5d7569e61a70a6',1,'Szfindel.Models.WeatherApi.main'],['../class_szfindel_1_1_models_1_1_weather.html#a99afbcd7e758d54dbc40a276bed974fc',1,'Szfindel.Models.Weather.main']]],
  ['matches_1',['Matches',['../class_szfindel_1_1_models_1_1_account_user.html#a1d5b8e4a92c5d549aa2a37a759bc64b0',1,'Szfindel.Models.AccountUser.Matches'],['../class_szfindel_1_1_models_1_1_database_context.html#a433cee97f29fcfc8236835deb30eedea',1,'Szfindel.Models.DatabaseContext.Matches']]],
  ['matchid_2',['MatchId',['../class_szfindel_1_1_models_1_1_match.html#a11c33e5955bf69c2f59eef59cc7504b8',1,'Szfindel::Models::Match']]],
  ['matchuserid_3',['MatchUserId',['../class_szfindel_1_1_models_1_1_match.html#aae887638fe4dbadef0dc27e3970b45f9',1,'Szfindel::Models::Match']]],
  ['messageid_4',['MessageId',['../class_szfindel_1_1_models_1_1_message.html#a8f84c75b8c46c8bf6ea1c408968e00c8',1,'Szfindel::Models::Message']]],
  ['messages_5',['Messages',['../class_szfindel_1_1_models_1_1_database_context.html#abff5bf05b2e835ad9b5eb18b48e0095b',1,'Szfindel::Models::DatabaseContext']]]
];
