var searchData=
[
  ['sendmessage_0',['SendMessage',['../interface_szfindel_1_1_interface_1_1_i_message.html#affa447acbbe61bd8de2cccfcd234de81',1,'Szfindel.Interface.IMessage.SendMessage()'],['../class_szfindel_1_1_controllers_1_1_message_controller.html#ad46e766d7ebb565f0178b20138ea8fb5',1,'Szfindel.Controllers.MessageController.SendMessage()'],['../class_szfindel_1_1_repo_1_1_message_repo.html#ad4c4bd8c92a46c95da8264a16c2fef12',1,'Szfindel.Repo.MessageRepo.SendMessage()']]],
  ['sendmessage_1',['sendmessage',['../class_szfindel_1_1_controllers_1_1_message_controller.html#abbb1bf29c22370872736e35b36538666',1,'Szfindel::Controllers::MessageController']]]
];
