var searchData=
[
  ['updateaccount_0',['UpdateAccount',['../interface_szfindel_1_1_interface_1_1_i_account.html#ad27622200eef115d36b2443c1c699873',1,'Szfindel.Interface.IAccount.UpdateAccount()'],['../class_szfindel_1_1_controllers_1_1_account_controller.html#a48c4fe6598fe442abc80fe13c3a17628',1,'Szfindel.Controllers.AccountController.UpdateAccount()'],['../class_szfindel_1_1_controllers_1_1_account_controller.html#a2c1b76ec0f9c6995145b84c60f1b2819',1,'Szfindel.Controllers.AccountController.UpdateAccount([FromForm] AccountUser updatedAccount, IFormFile? file)'],['../class_szfindel_1_1_repo_1_1_account_repo.html#a5995027b9a64a10beb55708752ce0a8a',1,'Szfindel.Repo.AccountRepo.UpdateAccount()']]],
  ['updateimage_1',['UpdateImage',['../interface_szfindel_1_1_interface_1_1_i_account.html#a902cacc1aee979cf3a36c8b90e571f87',1,'Szfindel.Interface.IAccount.UpdateImage()'],['../class_szfindel_1_1_repo_1_1_account_repo.html#a1f977ce3ec1004aff7c68bce9d716769',1,'Szfindel.Repo.AccountRepo.UpdateImage()']]],
  ['updatematch_2',['UpdateMatch',['../interface_szfindel_1_1_interface_1_1_i_match.html#a9856172483da9b865176dde4a91f8100',1,'Szfindel.Interface.IMatch.UpdateMatch()'],['../class_szfindel_1_1_repo_1_1_match_repo.html#ad60121f03de224b7395aafaac145b3a5',1,'Szfindel.Repo.MatchRepo.UpdateMatch()']]],
  ['useauthorization_3',['UseAuthorization',['../_program_8cs.html#aee15d952b351633e37db07ef3357d634',1,'Program.cs']]],
  ['usehttpsredirection_4',['UseHttpsRedirection',['../_program_8cs.html#aa4d447fc3129a3aa301d736b8bd04ae9',1,'Program.cs']]],
  ['user_5',['User',['../class_szfindel_1_1_models_1_1_user.html',1,'Szfindel.Models.User'],['../class_szfindel_1_1_models_1_1_account_user.html#a52c2d89a85b97de71701b5f30dce3487',1,'Szfindel.Models.AccountUser.User'],['../class_szfindel_1_1_models_1_1_user_hobby.html#ade31571ccb120bb39c3cd2586a95c757',1,'Szfindel.Models.UserHobby.User']]],
  ['user_2ecs_6',['User.cs',['../_user_8cs.html',1,'']]],
  ['usercontroller_7',['UserController',['../class_szfindel_1_1_controllers_1_1_user_controller.html',1,'Szfindel.Controllers.UserController'],['../class_szfindel_1_1_controllers_1_1_user_controller.html#a985a6287d14d777d37f6a24cc518edb0',1,'Szfindel.Controllers.UserController.UserController()']]],
  ['usercontroller_2ecs_8',['UserController.cs',['../_user_controller_8cs.html',1,'']]],
  ['userhobbies_9',['UserHobbies',['../class_szfindel_1_1_models_1_1_account_user.html#aaa0ac6e372990851195571fdb3eeb58c',1,'Szfindel.Models.AccountUser.UserHobbies'],['../class_szfindel_1_1_models_1_1_hobby.html#aa0d17fcff4aa0266c77d26450c3a33d6',1,'Szfindel.Models.Hobby.UserHobbies']]],
  ['userhobby_10',['UserHobby',['../class_szfindel_1_1_models_1_1_user_hobby.html',1,'Szfindel.Models.UserHobby'],['../class_szfindel_1_1_models_1_1_database_context.html#a4ac820efce5cff74f405e8dfc966df48',1,'Szfindel.Models.DatabaseContext.UserHobby']]],
  ['userhobby_2ecs_11',['UserHobby.cs',['../_user_hobby_8cs.html',1,'']]],
  ['userid_12',['UserId',['../class_szfindel_1_1_models_1_1_account_user.html#ad40bcf383ccef1e9aa18b1a4925996fa',1,'Szfindel.Models.AccountUser.UserId'],['../class_szfindel_1_1_models_1_1_user.html#a90bd67cdac5d3a5b815cbdc8632e569d',1,'Szfindel.Models.User.UserId'],['../class_szfindel_1_1_models_1_1_user_hobby.html#aad67ddf38cca232f13e94db3e5e21e55',1,'Szfindel.Models.UserHobby.UserId']]],
  ['username_13',['Username',['../class_szfindel_1_1_models_1_1_user.html#ac5578d62f1abed1638c13556ccd19516',1,'Szfindel::Models::User']]],
  ['userouting_14',['UseRouting',['../_program_8cs.html#a94c810d266751293a2d511a720a5625f',1,'Program.cs']]],
  ['userrepo_15',['UserRepo',['../class_szfindel_1_1_repo_1_1_user_repo.html',1,'Szfindel.Repo.UserRepo'],['../class_szfindel_1_1_repo_1_1_user_repo.html#a822d075551b3b4e997675fd28139ce48',1,'Szfindel.Repo.UserRepo.UserRepo()']]],
  ['userrepo_2ecs_16',['UserRepo.cs',['../_user_repo_8cs.html',1,'']]],
  ['users_17',['Users',['../class_szfindel_1_1_models_1_1_database_context.html#a35647b33257f899f6bbfad4d05661d27',1,'Szfindel::Models::DatabaseContext']]],
  ['usesession_18',['UseSession',['../_program_8cs.html#a5c33896bff93d8072abd01914b8370f8',1,'Program.cs']]],
  ['usestaticfiles_19',['UseStaticFiles',['../_program_8cs.html#a906a3ce545279a7a73941f1d7b64d7cf',1,'Program.cs']]],
  ['ustawienia_20',['Ustawienia',['../class_szfindel_1_1_controllers_1_1_account_controller.html#ae88b715c072a974a77d5562a67793166',1,'Szfindel::Controllers::AccountController']]]
];
