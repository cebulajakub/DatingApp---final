var searchData=
[
  ['iaccount_0',['IAccount',['../_account_repo_8cs.html#acd6e256617b423dd3569fb684a82b9f0',1,'AccountRepo.cs']]]
];
