var searchData=
[
  ['base_0',['base',['../class_szfindel_1_1_models_1_1_weather_api.html#ad2705cd02c5cbc5ef6dfd6f071888387',1,'Szfindel::Models::WeatherApi']]],
  ['builder_1',['builder',['../_program_8cs.html#a2f78352277081c620fd4cf92a5ce15e5',1,'Program.cs']]]
];
