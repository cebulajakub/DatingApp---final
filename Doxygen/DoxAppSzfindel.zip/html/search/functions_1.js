var searchData=
[
  ['checkmutuallike_0',['CheckMutualLike',['../interface_szfindel_1_1_interface_1_1_i_match.html#a5c9dc168e94baeaff3db099e3f03f3f7',1,'Szfindel.Interface.IMatch.CheckMutualLike()'],['../class_szfindel_1_1_repo_1_1_match_repo.html#a4cb7c34ad96893d29c0d0b8b51a26bb0',1,'Szfindel.Repo.MatchRepo.CheckMutualLike()']]],
  ['createuser_1',['CreateUser',['../interface_szfindel_1_1_interface_1_1_i_user.html#aa8d09e648801293c526981d99cacda29',1,'Szfindel.Interface.IUser.CreateUser()'],['../class_szfindel_1_1_repo_1_1_user_repo.html#a6be42f5f06e85a45c69c3b434a448d50',1,'Szfindel.Repo.UserRepo.CreateUser()']]]
];
