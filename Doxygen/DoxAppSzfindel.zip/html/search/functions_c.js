var searchData=
[
  ['register_0',['Register',['../class_szfindel_1_1_controllers_1_1_user_controller.html#ab27d0b3b35ceeba53930e83a58f7dc48',1,'Szfindel.Controllers.UserController.Register()'],['../class_szfindel_1_1_controllers_1_1_user_controller.html#a26473fb18478e30b7b764affbe632de4',1,'Szfindel.Controllers.UserController.Register([FromForm] User user)']]],
  ['removehobby_1',['Removehobby',['../class_szfindel_1_1_controllers_1_1_hobby_controller.html#a88e1676413b5da307f14e128ec72c632',1,'Szfindel::Controllers::HobbyController']]],
  ['removeuserhobby_2',['RemoveUserHobby',['../interface_szfindel_1_1_interface_1_1_i_hobby.html#a7642c8a2d5bd5cba85f0cfe7441386c0',1,'Szfindel.Interface.IHobby.RemoveUserHobby()'],['../interface_szfindel_1_1_interface_1_1_i_user_hobby.html#a8deecc033359cc30130f21c633d3aa86',1,'Szfindel.Interface.IUserHobby.RemoveUserHobby()'],['../class_szfindel_1_1_repo_1_1_hobby_repo.html#ada5558d03cf0e4c6d1116dae7a50550d',1,'Szfindel.Repo.HobbyRepo.RemoveUserHobby()']]],
  ['run_3',['Run',['../_program_8cs.html#aaa3dbf02e269c3ef7e8546d290c6b3dd',1,'Program.cs']]]
];
